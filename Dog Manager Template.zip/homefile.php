<div class="card p-5 shadow-sm">
      Logged in as <?= $_SESSION['email'] ?>
    <img src="img/misc/front_cover.png"></img>
    <font color="#444444" size="22" style="text-align: center;">Welcome to <?php echo(file_get_contents("site_config/WebsiteName.txt")); ?><br></font>
    <hr size="10">
    <h4 align="center">
    <p><img src="img/misc/dog1.jpg" width="200px" height="300px" style="text-align: center;"></img><br><?php echo(file_get_contents("site_config/HomeText.txt")); ?></p>
    <h4 align="right"><img src="img/misc/dog2.jpg" width="376px" height="343px"><img src="img/misc/dog3.jpg" width="290px" height="299px"><img src="img/misc/dog4.jpg" width="352px" height="200px"></img></img></img>
</div>